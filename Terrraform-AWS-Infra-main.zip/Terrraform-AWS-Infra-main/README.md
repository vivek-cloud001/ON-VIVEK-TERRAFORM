# Terrraform-AWS-Infra
Basic three tier infrastructure using Terraform

We will create the basic 3 tier application using Terrfarom.
